#!/bin/bash

set -e

tmpdir=$(mktemp -d)

echo "Clone installation source from GitHub.."
GIT_SSH_COMMAND='ssh -i github-ssh-key  -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null' \
git clone git@github.com:ohkajhu/okj-cache-fluxcd-clusters.git $tmpdir

cd $tmpdir

./scripts/validate.sh
./scripts/install.sh --overlay prd


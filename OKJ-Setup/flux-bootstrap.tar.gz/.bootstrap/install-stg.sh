#!/bin/bash

set -e

mkdir -p ~/.ssh
cp -r image-automation/  ~/.ssh/
chmod 700 ~/.ssh
chmod 400 ~/.ssh/image-automation/flux-k8s-apps-image-automation

tmpdir=$(mktemp -d)

echo "Clone installation source from GitHub.."
GIT_SSH_COMMAND='ssh -i github-ssh-key  -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null' \
git clone git@github.com:ohkajhu/okj-cache-fluxcd-clusters.git $tmpdir

cd $tmpdir

./scripts/validate.sh
./scripts/install.sh --overlay stg

